<?php 
  $course_duration = get_tutor_course_duration_context();;
?>

  <div class="tutor-single-loop-meta">
      <i class="flaticon-passage-of-time"></i> <span><?php echo $course_duration; ?></span>
  </div>