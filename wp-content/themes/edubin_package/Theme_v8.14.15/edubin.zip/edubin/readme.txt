=== Edubin===
Theme Name: Edubin 
Theme URI: https://thepixelcurve.com/wp/edubin/
Description: Edubin Education LMS WordPress Theme.
Author: Pixelcurve
Author URI: https://thepixelcurve.com/
Version: 8.14.15
Tags: two-columns, three-columns, left-sidebar, sticky-post, theme-options, translation-ready.
Text Domain: edubin
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==
Edubin Education LMS WordPress Theme.

For more information about edubin please go to https://thepixelcurve.com/

== Installation ==

Please see installation guide in Documentation. here https://thepixelcurve.com/support/docs/edubin/